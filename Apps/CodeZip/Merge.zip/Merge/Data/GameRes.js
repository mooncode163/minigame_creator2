 

var GameRes = cc.Class({
    extends: cc.Object,
    statics: {

    },
 
    properties: {    
       
    },
 
 


});

