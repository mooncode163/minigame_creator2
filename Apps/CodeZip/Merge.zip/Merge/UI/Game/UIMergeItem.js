var UIViewController = require("UIViewController");
var UIView = require("UIView");
var UIMergeItem = cc.Class({
    extends: UIView,
    statics: {
        
    },

    properties: { 
    },
    onLoad: function () {
        this._super(); 
    },
    start: function () {
        this._super();
    },
    
 



});
