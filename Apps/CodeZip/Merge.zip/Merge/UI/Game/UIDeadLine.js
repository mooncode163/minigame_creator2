var UIViewController = require("UIViewController");
var UIView = require("UIView"); 

var UIDeadLine = cc.Class({
    extends: UIView,
    statics: {
        
    },

    properties: { 
    },
    onLoad: function () {
        this._super(); 
    },
    start: function () {
        this._super();
    },

    

    
});
