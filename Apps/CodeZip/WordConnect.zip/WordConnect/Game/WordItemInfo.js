var WordItemInfo = cc.Class({
    extends: cc.ItemInfo,// cc.ItemInfo,
    properties: {
        colorid: "",
        count: 0,
        listPic0: {
            default: [],
            type: cc.Object
        },
        listPic1: {
            default: [],
            type: cc.Object
        },
        listColorFilter: {
            default: [],
            type: cc.Object
        },
        isColor: false,
        //posNormalWorld:
        // public List<object> listFormulation;//公式
        // public string[] listLetter;
        // public string[] listAnswer;//答案 LO|SOL 
        // public string[] listError;
        // public string gameType;
        // public string author;
        // public string year;
        // public string style;
        // public string album;
        // public string intro;
        // public string translation;
        // public string appreciation;
        // public string pinyin;
        // public string head;
        // public string end;
        // public string tips;

       // public List<PoemContentInfo> listPoemContent;


    },
});
cc.WordItemInfo = module.export = WordItemInfo; 