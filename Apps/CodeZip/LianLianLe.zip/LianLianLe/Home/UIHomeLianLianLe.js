var UIHomeBase = require("UIHomeBase");
var AppRes = require("AppRes");
//var LayoutScale = require("LayoutScale");
// var Common = require("Common"); 
cc.Class({
    extends: UIHomeBase,
    properties: {
    },
    onLoad: function () {
        this._super();
        this.LayOut();

    },
    LayOut: function () {
        this._super();


    },


});

