var UIView = require("UIView");
var UIGameWinIdiomConnect = cc.Class({
    extends: UIView,// cc.ItemInfo, 
    properties: {
     
    },

    onLoad: function () {

    }, 

    LayOut() {
        
    },

});

